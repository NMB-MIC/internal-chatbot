# MIC 9000

Ask your internal knowledge base.

Grounded answers for MIC documents, Kafka/IOT support, and machine-status runbooks.

Use the settings panel to choose a reference document and scope behavior.
